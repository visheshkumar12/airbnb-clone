import { useState } from 'react';
import Header from './components/Header';
import Gallery from './components/Gallery';
import SubNav from './components/SubNav';
import ListingBody from './components/ListingBody';
import BookingCard from './components/BookingCard';
import PhotoTour from './components/PhotoTour';
import Lightbox from './components/Lightbox';

export default function App() {
  const [tourOpen, setTourOpen] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [photoIndex, setPhotoIndex] = useState(0);

  const openPhoto = (i) => { setPhotoIndex(i); setLightboxOpen(true); };

  return (
    <>
      <Header />
      <Gallery onOpenPhoto={openPhoto} onShowAll={() => setTourOpen(true)} />
      <SubNav />
      <main className="wrap">
        <div className="content">
          <ListingBody />
          <BookingCard />
        </div>
      </main>
      <footer className="wrap">© 2026 villastay, Inc. · Privacy · Terms · Sitemap</footer>

      <PhotoTour open={tourOpen} onClose={() => setTourOpen(false)} onOpenPhoto={openPhoto} />
      <Lightbox
        open={lightboxOpen}
        index={photoIndex}
        onClose={() => setLightboxOpen(false)}
        onNavigate={setPhotoIndex}
      />
    </>
  );
}
