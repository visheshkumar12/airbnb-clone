export const photos = [
  { id: 0, cls: 'p1', url: 'https://picsum.photos/seed/villagoa-ext/1000/750' },
  { id: 1, cls: 'p2', url: 'https://picsum.photos/seed/villagoa-living/1000/750' },
  { id: 2, cls: 'p3', url: 'https://picsum.photos/seed/villagoa-pool/1000/750' },
  { id: 3, cls: 'p4', url: 'https://picsum.photos/seed/villagoa-bed/1000/750' },
  { id: 4, cls: 'p5', url: 'https://picsum.photos/seed/villagoa-bath/1000/750' },
  { id: 5, cls: 'p6', url: 'https://picsum.photos/seed/villagoa-view/1000/750' },
  { id: 6, cls: 'p7', url: 'https://picsum.photos/seed/villagoa-dining/1000/750' },
  { id: 7, cls: 'p8', url: 'https://picsum.photos/seed/villagoa-kitchen/1000/750' },
];

export const nearbyStays = [
  { title: 'Beautiful Studio with a view to die for', price: '₹23,600', rating: '4.91', img: 'https://picsum.photos/seed/villagoa-living/500/400' },
  { title: 'NAQAB - 1bhk with private pool', price: '₹42,218', rating: '4.95', img: 'https://picsum.photos/seed/villagoa-pool/500/400' },
  { title: 'Greentique Luxury Flat with plunge pool', price: '₹44,506', rating: '4.94', img: 'https://picsum.photos/seed/villagoa-kitchen/500/400' },
  { title: 'The Tropical Studio | 5 mins to Beach', price: '₹22,824', rating: '4.96', img: 'https://picsum.photos/seed/villagoa-ext/500/400' },
  { title: 'Luxury Casa Bella 1BHK with plunge pool', price: '₹39,942', rating: '4.95', img: 'https://picsum.photos/seed/villagoa-nearby1/500/400' },
];

export const reviews = [
  { name: 'Amit', sub: '2 months on Airbnb', time: '1 week ago', text: 'Very helpful and responsive team. Safe and peaceful stay. loved everything about the property.', initial: 'A', color: '#d9a86a' },
  { name: 'Aheesh', sub: '3 years on Airbnb', time: '2 weeks ago', text: 'We had a wonderful stay. The apartment was clean, comfortable, and exactly as shown in the photos.', img: 'https://picsum.photos/seed/host-aheesh/100/100' },
  { name: 'Samiksha', sub: '8 months on Airbnb', time: 'May 2026', text: 'the host nitish was really great help', img: 'https://picsum.photos/seed/host-samiksha/100/100' },
  { name: 'Vedant', sub: '4 years on Airbnb', time: 'May 2026', text: 'We had an amazing stay at this property in Goa! The entire home was spotless and exceptionally well-maintained.', initial: 'V', color: '#a685d9' },
];

export const coHosts = [
  { name: 'Sharath', initials: 'Sh', color: '#3d5c8a' },
  { name: 'Aman Dev Pahwa', initials: 'AD', color: '#8a5c3d' },
  { name: 'Maria Karen Priyanka', initials: 'MK', color: '#5c8a5c' },
  { name: 'Simran', initials: 'Si', color: '#8a3d6b' },
  { name: 'Pallavi', initials: 'Pa', color: '#a67c3d' },
  { name: 'Sanyukta', initials: 'Sa', color: '#3d8a7c' },
  { name: 'Shruti', initials: 'S', color: '#e6b0b0' },
  { name: 'Amisha', initials: 'A', color: '#b0c4e6' },
];

export const ratingCategories = [
  { label: 'Cleanliness', value: '5.0' },
  { label: 'Accuracy', value: '5.0' },
  { label: 'Check-in', value: '5.0' },
  { label: 'Communication', value: '5.0' },
  { label: 'Location', value: '4.8' },
  { label: 'Value', value: '4.8' },
];

export const reviewChips = ['🛋️ Comfort 6', '✅ Accuracy 5', '🛁 Hot tub 5', '📦 Condition 4', '🎁 Hospitality 8', '🧴 Cleanliness 4', '🎀 Amenities 2'];
