import { useState } from 'react';
import { reviews, nearbyStays, coHosts, ratingCategories, reviewChips } from '../data/listing';

const FULL_DESC = "🌴 Plan Your Relaxing Holiday at Amor De Goa by Mirashya Homes! ✨ Stay in this cozy home nestled in the heart of Candolim, just minutes from the beach. Enjoy a private pool, alfresco dining area, and thoughtfully designed interiors perfect for families and friends. Wake up to birdsong, spend afternoons by the pool, and unwind in the evening with the sea breeze drifting through the open living space.";
const SHORT_DESC = FULL_DESC.slice(0, 150) + '…';

function Avatar({ review }) {
  if (review.img) return <div className="av" style={{ width: 44, height: 44, borderRadius: '50%', backgroundImage: `url(${review.img})`, backgroundSize: 'cover', flexShrink: 0 }} />;
  return <div className="av" style={{ background: review.color }}>{review.initial}</div>;
}

export default function ListingBody() {
  const [expanded, setExpanded] = useState(false);

  return (
    <div>
      <div className="section" id="photos">
        <div className="favcard">
          <svg className="laurel" width="34" height="34" viewBox="0 0 24 24" fill="none"><path d="M6 20c-3-2-4-6-2-10 1 2 1 4 2 5-1-3 0-6 2-8 0 3 1 5 2 6-1-2 0-5 2-7" stroke="#222" strokeWidth="1.3"/></svg>
          <div className="txt"><b>Guest favourite</b>One of the most loved homes on Airbnb, according to guests</div>
          <div className="score">4.95<div className="stars">★★★★★</div></div>
          <div className="revs"><b>19</b>Reviews</div>
        </div>
      </div>

      <div className="section hostrow">
        <div className="hostavatar">MIRASHYA</div>
        <div><h3>Hosted by Mirashya Homes</h3><div className="sub">2 years hosting</div></div>
      </div>

      <div className="section">
        <div className="feature"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 12a8 8 0 0 1 16 0" stroke="#222" strokeWidth="1.5"/><path d="M12 12v9M9 21h6" stroke="#222" strokeWidth="1.5"/></svg><div><b>Outdoor entertainment</b><p>The pool and alfresco dining are great for summer trips.</p></div></div>
        <div className="feature"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="2.5" stroke="#222" strokeWidth="1.4"/><path d="M12 9.5c0-3 1-5 3-5s2 2 0 3M12 14.5c0 3-1 5-3 5s-2-2 0-3M14.5 12c3 0 5 1 5 3s-2 2-3 0M9.5 12c-3 0-5-1-5-3s2-2 3 0" stroke="#222" strokeWidth="1.4"/></svg><div><b>Designed for staying cool</b><p>Beat the heat with the A/C and ceiling fan.</p></div></div>
        <div className="feature"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="6" y="3" width="12" height="18" rx="1.5" stroke="#222" strokeWidth="1.4"/><circle cx="14.5" cy="12" r="1" fill="#222"/></svg><div><b>Self check-in</b><p>You can check in with the building staff.</p></div></div>
      </div>

      <div className="section"><div className="translatebar">Some info has been automatically translated. <u>Show original</u></div></div>

      <div className="section desc">
        <p>{expanded ? FULL_DESC : SHORT_DESC}</p>
        <button className="showmore" onClick={() => setExpanded(!expanded)}>
          {expanded ? 'Show less' : 'Show more'}{' '}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="#222" strokeWidth="2"/></svg>
        </button>
      </div>

      <div className="section" id="amenities">
        <h2 style={{ fontSize: 20, marginBottom: 4 }}>What this place offers</h2>
        <div className="amen-grid">
          <div className="amen-item">🏊 Private pool</div><div className="amen-item">📶 Wifi</div>
          <div className="amen-item">🍳 Kitchen</div><div className="amen-item">🅿️ Free parking</div>
          <div className="amen-item">❄️ Air conditioning</div><div className="amen-item">🌀 Ceiling fan</div>
          <div className="amen-item">🔑 Self check-in</div><div className="amen-item">📷 Security cameras</div>
        </div>
        <button className="showallbtn">Show all amenities</button>
      </div>

      <Calendar />

      <div className="section" id="reviews">
        <div className="scorewrap">
          <div className="bignum">
            <svg width="30" height="46" viewBox="0 0 24 40" fill="none"><path d="M14 38c-6-4-8-12-4-20 2 4 2 8 4 10-2-6 0-12 4-16 0 6 2 10 4 12-2-4 0-10 4-14" stroke="#222" strokeWidth="1.3"/></svg>
            4.95
            <svg width="30" height="46" viewBox="0 0 24 40" fill="none" style={{ transform: 'scaleX(-1)' }}><path d="M14 38c-6-4-8-12-4-20 2 4 2 8 4 10-2-6 0-12 4-16 0 6 2 10 4 12-2-4 0-10 4-14" stroke="#222" strokeWidth="1.3"/></svg>
          </div>
          <div className="favtitle">Guest favourite</div>
          <div className="favdesc">This home is a guest favourite based on ratings, reviews and reliability</div>
          <a className="reviewlink" href="#">How reviews work</a>
        </div>
        <div className="ratingrow">
          <div className="ratingcol"><b>Overall rating</b>
            <div className="bars">
              <div className="barrow">5<div className="barbg"><i style={{ width: '96%' }}></i></div></div>
              <div className="barrow">4<div className="barbg"><i style={{ width: '8%' }}></i></div></div>
              <div className="barrow">3<div className="barbg"><i style={{ width: '0%' }}></i></div></div>
              <div className="barrow">2<div className="barbg"><i style={{ width: '0%' }}></i></div></div>
              <div className="barrow">1<div className="barbg"><i style={{ width: '0%' }}></i></div></div>
            </div>
          </div>
          {ratingCategories.map((c) => (
            <div className="ratingcol" key={c.label}>{c.label}<div className="num">{c.value}</div></div>
          ))}
        </div>
        <div className="chiprow">
          {reviewChips.map((c) => <div className="chip" key={c}>{c}</div>)}
        </div>
        <div className="reviews">
          {reviews.map((r) => (
            <div className="review" key={r.name}>
              <div className="who">
                <Avatar review={r} />
                <div><b>{r.name}</b><span>{r.sub}</span></div>
              </div>
              <div className="stars">★★★★★ · {r.time}</div>
              <p>{r.text}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="section" id="location">
        <h2 style={{ fontSize: 20, marginBottom: 14 }}>Where you'll be</h2>
        <div className="maploc">Candolim, Goa, India</div>
        <div className="map">
          <div className="mapgrid"></div>
          <div className="mapdot" style={{ top: '30%', left: '32%' }}></div>
          <div className="mapdot" style={{ top: '55%', left: '70%' }}></div>
          <div className="pinhome"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z" fill="#fff"/></svg></div>
          <div className="mapbtn" style={{ top: 16, left: 16 }}><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#222" strokeWidth="1.6"/><path d="M21 21l-4-4" stroke="#222" strokeWidth="1.6"/></svg></div>
          <div className="mapbtn" style={{ top: 16, right: 16 }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 12h14" stroke="#222" strokeWidth="2"/></svg></div>
          <div className="mapbtn" style={{ top: 60, right: 16 }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#222" strokeWidth="2"/></svg></div>
        </div>
      </div>

      <div className="section">
        <h2 style={{ fontSize: 20, marginBottom: 20 }}>Meet your host</h2>
        <div className="hostcardbig">
          <div className="hostbox">
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div className="av" style={{ margin: '0 auto', width: 64, height: 64, borderRadius: '50%', background: '#1c3d2e', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700 }}>MIRASHYA</div>
              <div className="hostname" style={{ fontSize: 17, marginTop: 10 }}>Mirashya Homes</div>
              <div className="hostrole">Host</div>
              <div className="stat"><b>1,463</b>Reviews</div>
              <div className="stat"><b>4.68 ★</b>Rating</div>
              <div className="stat"><b>2</b>Years hosting</div>
            </div>
          </div>
          <div>
            <div className="cohosttitle">Co-Hosts</div>
            <div className="cohostgrid">
              {coHosts.map((h) => (
                <div className="cohost" key={h.name}>
                  <div className="av" style={{ background: h.color }}>{h.initials}</div>{h.name}
                </div>
              ))}
            </div>
            <div className="hostdetailtitle">Host details</div>
            <div className="hostdetails"><p>Response rate: 100%</p><p>Responds within an hour</p></div>
            <button className="msgbtn">Message host</button>
          </div>
        </div>
        <div className="hostfact">💡 Born in the 80s</div>
        <div className="hostfact">🎓 Where I went to school: NICMAR GOA</div>
      </div>

      <div className="section">
        <h2 style={{ fontSize: 20, marginBottom: 20 }}>Things to know</h2>
        <div className="knowgrid">
          <div className="knowcol"><h4>House rules</h4><p>Check-in after 3:00 pm</p><p>Checkout before 11:00 am</p><p>3 guests maximum</p><a href="#">Learn more</a></div>
          <div className="knowcol"><h4>Safety &amp; property</h4><p>Smoke alarm not reported</p><p>Exterior security cameras on property</p><a href="#">Learn more</a></div>
          <div className="knowcol"><h4>Cancellation policy</h4><p>Free cancellation before 17 October. Cancel before check-in on 18 October for a partial refund.</p><a href="#">Learn more</a></div>
        </div>
      </div>

      <div className="section" style={{ borderBottom: 'none' }}>
        <div className="nearbyhead">
          <h2 style={{ fontSize: 20 }}>More stays nearby</h2>
          <div className="nearbypage">1 / 2<button className="circlebtn">‹</button><button className="circlebtn">›</button></div>
        </div>
        <div className="nearbyrow">
          {nearbyStays.map((s) => (
            <div className="nearbycard" key={s.title}>
              <div className="ph" style={{ backgroundImage: `url(${s.img})`, height: 150, borderRadius: 12, marginBottom: 8 }} />
              <div className="t">{s.title}</div>
              <div className="p">{s.price} · ★ {s.rating}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Calendar() {
  const dow = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  return (
    <div className="section">
      <div className="calendarhead">5 nights in Candolim</div>
      <div className="calendarsub">18 Oct 2026 - 23 Oct 2026</div>
      <div className="calwrap">
        <div className="calmonth">
          <h4>October 2026</h4>
          <div className="calgrid">
            {dow.map((d, i) => <div className="dow" key={'o' + i}>{d}</div>)}
            <div></div><div></div>
            {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => {
              const cls = d === 18 || d === 23 ? 'day pick' : d > 18 && d < 23 ? 'day range' : 'day';
              return <div className={cls} key={d}>{d}</div>;
            })}
          </div>
        </div>
        <div className="calmonth">
          <h4>November 2026</h4>
          <div className="calgrid">
            {dow.map((d, i) => <div className="dow" key={'n' + i}>{d}</div>)}
            {Array.from({ length: 30 }, (_, i) => i + 1).map((d) => (
              <div className={d >= 18 && d <= 24 ? 'day dim' : 'day'} key={d}>{d}</div>
            ))}
          </div>
        </div>
      </div>
      <div className="calfoot">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#222" strokeWidth="1.4"/></svg>
        <u>Clear dates</u>
      </div>
    </div>
  );
}
