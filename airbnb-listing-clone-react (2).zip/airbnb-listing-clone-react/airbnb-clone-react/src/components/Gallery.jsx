import { photos } from '../data/listing';

export default function Gallery({ onOpenPhoto, onShowAll }) {
  return (
    <main className="wrap">
      <div className="titlebar">
        <h1>Amor De Goa by Mirashya Homes</h1>
        <div className="meta">Entire rental unit in Candolim, Goa, India</div>
      </div>
      <div className="gallery">
        {photos.slice(0, 5).map((p, i) => (
          <div className="gtile" key={p.id} onClick={() => onOpenPhoto(i)}>
            <div className="ph" style={{ backgroundImage: `url(${p.url})`, width: '100%', height: '100%' }} />
            {i === 4 && (
              <button
                className="showall"
                onClick={(e) => { e.stopPropagation(); onShowAll(); }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="3" width="8" height="8" rx="1.5" stroke="#222" strokeWidth="1.6"/>
                  <rect x="13" y="3" width="8" height="8" rx="1.5" stroke="#222" strokeWidth="1.6"/>
                  <rect x="3" y="13" width="8" height="8" rx="1.5" stroke="#222" strokeWidth="1.6"/>
                  <rect x="13" y="13" width="8" height="8" rx="1.5" stroke="#222" strokeWidth="1.6"/>
                </svg>
                Show all photos
              </button>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}
