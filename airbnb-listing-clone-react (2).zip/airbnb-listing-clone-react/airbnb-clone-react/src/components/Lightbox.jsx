import { useEffect, useRef, useState } from 'react';
import { photos } from '../data/listing';

export default function Lightbox({ open, index, onClose, onNavigate }) {
  const closeBtnRef = useRef(null);
  const lastFocused = useRef(null);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    if (open) {
      lastFocused.current = document.activeElement;
      closeBtnRef.current?.focus();
      document.body.style.overflow = 'hidden';
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e) => {
      if (!open) return;
      if (e.key === 'Escape') handleClose();
      if (e.key === 'ArrowLeft') go(-1);
      if (e.key === 'ArrowRight') go(1);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  });

  const handleClose = () => {
    onClose();
    lastFocused.current?.focus();
  };

  const go = (dir) => {
    const next = index + dir;
    if (next < 0 || next >= photos.length) return;
    setFading(true);
    setTimeout(() => { onNavigate(next); setFading(false); }, 140);
  };

  if (!open) return null;
  const photo = photos[index];

  return (
    <div className="lightbox open" role="dialog" aria-modal="true" aria-label="Photo viewer">
      <button className="lb-close" ref={closeBtnRef} aria-label="Close photo viewer" onClick={handleClose}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 4l16 16M20 4L4 20" stroke="#fff" strokeWidth="1.8"/></svg>
      </button>
      <div className="lb-count">{index + 1} / {photos.length}</div>
      <button className="lb-nav lb-prev" aria-label="Previous photo" disabled={index === 0} onClick={() => go(-1)}>‹</button>
      <div
        className={`lb-img ph${fading ? ' fading' : ''}`}
        style={{ backgroundImage: `url(${photo.url})` }}
      />
      <button className="lb-nav lb-next" aria-label="Next photo" disabled={index === photos.length - 1} onClick={() => go(1)}>›</button>
    </div>
  );
}
