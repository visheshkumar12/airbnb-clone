import { useEffect, useRef } from 'react';
import { photos } from '../data/listing';

export default function PhotoTour({ open, onClose, onOpenPhoto }) {
  const closeBtnRef = useRef(null);
  const lastFocused = useRef(null);

  useEffect(() => {
    if (open) {
      lastFocused.current = document.activeElement;
      closeBtnRef.current?.focus();
      document.body.style.overflow = 'hidden';
    }
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  useEffect(() => {
    const onKey = (e) => { if (open && e.key === 'Escape') handleClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  });

  const handleClose = () => {
    onClose();
    lastFocused.current?.focus();
  };

  return (
    <div className={`tour${open ? ' open' : ''}`} role="dialog" aria-modal="true" aria-label="Photo tour">
      <div className="tourbar">
        <button className="closebtn" ref={closeBtnRef} aria-label="Close photo tour" onClick={handleClose}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 4l16 16M20 4L4 20" stroke="#222" strokeWidth="1.8"/></svg>
        </button>
        <div style={{ fontWeight: 600, fontSize: 15 }}>Amor De Goa by Mirashya Homes</div>
        <div style={{ width: 40 }}></div>
      </div>
      <div className="tourgrid">
        {photos.map((p, i) => (
          <div
            className="ph"
            style={{ backgroundImage: `url(${p.url})` }}
            key={p.id}
            tabIndex={0}
            role="button"
            onClick={() => onOpenPhoto(i)}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpenPhoto(i); } }}
          />
        ))}
      </div>
    </div>
  );
}
