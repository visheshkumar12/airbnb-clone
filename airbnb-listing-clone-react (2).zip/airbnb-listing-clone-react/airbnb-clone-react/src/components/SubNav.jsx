import { useState } from 'react';

const TABS = ['photos', 'amenities', 'reviews', 'location'];

export default function SubNav() {
  const [active, setActive] = useState('photos');

  const go = (id) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <nav className="subnav">
      <div className="wrap">
        <div className="tabs">
          {TABS.map((t) => (
            <a
              key={t}
              href={`#${t}`}
              className={active === t ? 'active' : ''}
              onClick={(e) => { e.preventDefault(); go(t); }}
            >
              {t[0].toUpperCase() + t.slice(1)}
            </a>
          ))}
        </div>
        <div className="subright">
          <div className="subprice">
            <b>₹28,499</b><span> for 5 nights</span>
            <div className="r">★ 4.95 · 19 reviews</div>
          </div>
          <button className="reservebtn">Reserve</button>
        </div>
      </div>
    </nav>
  );
}
