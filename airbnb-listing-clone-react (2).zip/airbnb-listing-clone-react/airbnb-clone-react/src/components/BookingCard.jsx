import { useState } from 'react';

export default function BookingCard() {
  const [guests, setGuests] = useState(2);
  const cycleGuests = () => setGuests((g) => (g >= 6 ? 1 : g + 1));

  return (
    <aside className="book">
      <div className="discount">
        <div style={{ width: 32, height: 32, borderRadius: 8, background: '#e8f3e6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>🏷️</div>
        <div className="txt">Get 10% off your next stay. <u>Terms apply</u></div>
        <button className="claimbtn">Claim</button>
      </div>
      <div className="bookcard">
        <div className="price"><u>₹28,499</u> <span>for 5 nights</span></div>
        <div className="datebox">
          <div className="row">
            <div className="cell"><label>CHECK-IN</label><div>10/18/2026</div></div>
            <div className="cell"><label>CHECKOUT</label><div>10/23/2026</div></div>
          </div>
          <div
            className="guestcell"
            tabIndex={0}
            role="button"
            aria-expanded="false"
            onClick={cycleGuests}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); cycleGuests(); } }}
          >
            <div><label>GUESTS</label><div>{guests} {guests === 1 ? 'guest' : 'guests'}</div></div>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="#222" strokeWidth="2"/></svg>
          </div>
        </div>
        <div className="freecancel">Free cancellation before <b>17 October</b></div>
        <button className="reserve">Reserve</button>
        <div className="noteline">You won't be charged yet</div>
      </div>
      <div className="reportline">🚩 <u>Report this listing</u></div>
    </aside>
  );
}
