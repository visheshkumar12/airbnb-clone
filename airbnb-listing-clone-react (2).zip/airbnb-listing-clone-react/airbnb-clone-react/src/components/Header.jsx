export default function Header() {
  return (
    <header>
      <div className="headrow">
        <div className="logo">
          <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
            <path d="M16 2c1.8 0 3 1.1 4.4 3.6 1 1.8 5.6 10 6.9 13 .8 1.9 1.1 3.3 1.1 4.6 0 4.1-3 6.8-6.8 6.8-2.9 0-4.9-1.6-5.6-2.8-.7 1.2-2.7 2.8-5.6 2.8-3.8 0-6.8-2.7-6.8-6.8 0-1.3.3-2.7 1.1-4.6 1.3-3 5.9-11.2 6.9-13C13 3.1 14.2 2 16 2z" fill="#FF385C"/>
          </svg>
          <span>villastay</span>
        </div>
        <div className="searchpill" tabIndex={0} role="button" aria-label="Search">
          <span>Goa</span><span>Any week</span><span>Add guests</span>
          <div className="go">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="7" stroke="#fff" strokeWidth="2.4"/>
              <path d="M21 21l-4-4" stroke="#fff" strokeWidth="2.4" strokeLinecap="round"/>
            </svg>
          </div>
        </div>
        <div className="userpill" tabIndex={0} role="button" aria-label="Menu">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M3 6h18M3 12h18M3 18h18" stroke="#222" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <div className="avatar"></div>
        </div>
      </div>
    </header>
  );
}
